
import os.path
gryla=True
key=False
rustySpoon = False
chestOpen = False

path = 'scenario.txt'
infile = open(path, 'r')
readFile = infile.read()
print(readFile)


path = 'settingOff.txt'
infile = open(path, 'r')
readFile = infile.read()
print (readFile)


path = 'theEncounter.txt'
infile = open(path, 'r')
readFile = infile.read()
print (readFile)


isInteger = False
while isInteger != True:
    firstInput=input('Do you want to enter(1) or flee(2)?')
    if firstInput == ('1'):
        print('You enter the room.')
        isInteger = True
    else:
        print('You leave and are filled with saddness. Is that really what you want? Try again.')
    

path = 'theEncounter 2.txt'
infile = open (path, 'r')
readFile = infile.read()
print (readFile)
isInteger = False
while isInteger !=True:
    secondInput=input('Do you want to search the table (1), enter the kitchen (3), or enter the bedroom (4)?')
    if secondInput == ('1'):
        path = 'tableSearch.txt'
        infile = open (path, 'r')
        readFile = infile.read()
        print (readFile)
        rustySpoon = True

    if secondInput == ('3'):
        path = 'kitchen.txt'
        infile = open (path, 'r')
        readFile = infile.read()
        print (readFile)
        isInteger = True
isInteger = False
while isInteger !=True:
    thirdInput =input('Do you want to search (1), go back to the living room (2), or go down the stairs (4)?')
    if thirdInput == ('1'):
        print('There\'s nothing here for you.')
    else:
        print ('You have to choose one of the numbers. You\'re in too deep, now')
    if secondInput == ('4'):
        path = 'bedroom.txt'
        infile = open (path, 'r')
        readFile = infile.read()
        print (readFile)
        isInteger = True
isInteger = False
while isInteger !=True:
    fifthInput = input('Do you want to search (1), go back to the living room (2), or attempt to open the chest? (3)')
    if fifthInput == ('1'):
            print ('There is nothing in this room worth taking.')

    if fifthInput == ('2'):
            path = 'theEncounter 2.txt'
            infile = open (path, 'r')
            readFile = infile.read()
            print (readFile)
            isInteger = True

    if thirdInput == ('4'):
        path = 'basementDesc.txt'
        infile = open (path, 'r')
        readFile = infile.read()
        print (readFile)
        isInteger = True
    isInteger = False
    while isInteger !=True:
        secondInput=input('Do you want to search the table (1), enter the kitchen (3), or enter the bedroom (4)?')
    if secondInput == ('1'):
        path = 'tableSearch.txt'
        infile = open (path, 'r')
        readFile = infile.read()
        print (readFile)
        rustySpoon = True
isInteger = False
while isInteger !=True:
    grylaInput = input('What do you want to do? You can attack (1), persuade her (2), or observe her (3)?')
    if grylaInput == ('2'):
        print ('You look at Gryla and try to persuade her that you don\'t fear her.')
        import random
        grylaPersuadeRoll = random.randrange ((20)+1)+4
        playerPersuadeRoll = random.randrange(20)+1
        print (playerPersuadeRoll)
        print (grylaPersuadeRoll)

        if playerPersuadeRoll > grylaPersuadeRoll:
            print ('Gryla disappears. You have proven that you do not fear her, and she is no longer a danger to you. You obtain a Golden Key.')
            key = True
            gryla = False
            isInteger=True

        else:
            print ('It failed. You can no longer attempt to try to persuade her.')

    if grylaInput == ('3'):
        print ('You look closely at Gryla, squinting your eyes as you inspect her withered features.')
    grylaConsiderRoll = random.randrange ((20)+1)-2
    playerConsiderRoll = random.randrange(20)+1
    print (playerConsiderRoll)
    print (grylaConsiderRoll)

    if playerConsiderRoll > grylaConsiderRoll:
        print ('As you look closer, you realize that she is just sick, and that you can easily cure her! You do so and the kind, chubby old woman thanks you and gives you the Golden Key.')
        key = True
        gryla = False
        isInteger = True
                
    isInteger = False
    while isInteger !=True:
        if grylaInput == ('1'):
            roll2Hit = random.randrange(20)+1
            print ('You go to attack Gryla')
            print (roll2Hit)
            if roll2Hit <12:
                print ('You miss')
            if roll2Hit==20:
                print ('Critical Hit! Gryla dies.')
                isInteger = True
                gryla = False
            elif roll2Hit==1:
                print ('Critical Miss!')
            print ('Gryla attacks you.')
            grylaRoll = random.randrange(20)+1
            print (grylaRoll)
            if grylaRoll <12:
                print ('She misses.')
            roll2Hit = random.randrange(20)+1
            print ('You go to attack Gryla')
            print (roll2Hit)
            if roll2Hit <12:
                print ('You miss')
            elif roll2Hit >12:
                print ('You Win! Gryla dies!')
            isInteger = True
if gryla == False:
    basementExit= input ('You go back upstairs. You go through the kitchen and are back in the living room (2). Would you like to leave (1), or go into the bedroom (4)?')
    if basementExit == ('1'):
        print ('You can\'t help but feel like you\'re forgetting something, but it\'s probably fine. You leave the house, feeling satisfied of your venture. Game Over!')
        exit ('x')
    elif basementExit == ('2'):
        print ('You\'re back in the bedroom. Now what?')
    lastInput = input('Would you like to leave (1), or open the chest (2)?')
    if lastInput == ('1'):
        print ('You can\'t help but feel like you\'re forgetting something, but it\'s probably fine. You leave the house, feeling satisfied of your venture. Game Over!')
    elif lastInput == ('2'):
        if key == True:
            path = 'theEncounter.txt'
            infile = open(path, 'r')
            readFile = infile.read()
            print (readFile)

print ('You leave, with all your treausure, loot, and lifelong experience. Congratulations! The end.')
                        
        


 




  

#I struggled with this a lot, to be honest. A list of things I struggled with that I couldn't figure out in the end:
    #Putting things in order was still a struggle for me. I would list an if, and an elif, but then I didn't know how to segway into a different part of the code without it failing.
    #I also couldn't figure out how to get the code at the end to work, to get the player to get back up to the chest and how to limit the player from opening it.
            
            
